from django.apps import AppConfig


class LandDataConfig(AppConfig):
    name = 'Land_Data'
 #   name = 'Category'
 '''
    name = 'Application'
    

class LandDataConfig(AppConfig):
    name = 'Category'

class LandDataConfig(AppConfig):
 '''
 #   name = 'Application'
