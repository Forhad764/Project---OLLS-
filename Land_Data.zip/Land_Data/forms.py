from django import forms

class landowner_form(forms.Form):
    post= forms.CharField()
   