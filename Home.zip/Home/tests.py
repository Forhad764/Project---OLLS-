#from django.test import TestCase

# Create your tests here.
#def upload_location(instance, filename):
   # filebase, extension = filename.split('.')
  #  return 'images/%s.%s' % (instance.name.name, extension)
'''
import os
from uuid import uuid4
#from .views import Register
'''
#def path_and_rename(path):
 #   def wrapper(instance, filename):
  #      ext = filename.split('.')[-1]
        # get filename
   #     if instance.pk:
   #         filename = '{}.{}'.format(instance.pk, ext)
    #    else:
            # set filename as random string
     #       filename = '{}.{}'.format(uuid4().hex, ext)
        # return the whole path to the file
      #  return os.path.join(path, filename)
    #return wrapper

#ImageField(upload_to=path_and_rename('Profile_pic/'))
